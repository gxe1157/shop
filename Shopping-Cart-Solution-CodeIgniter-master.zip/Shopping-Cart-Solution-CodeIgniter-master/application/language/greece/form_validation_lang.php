<?php 
$lang['required'] = '&Alpha;&pi;&alpha;&iota;&tau;&omicron;ύ&mu;&epsilon;&nu;&alpha; &pi;&epsilon;&delta;ί&alpha;';
