<?php 
$lang['first'] = ' &pi;&rho;ώ&tau;&omicron;&sigmaf;';
$lang['last'] = '&tau;&epsilon;&lambda;&epsilon;&upsilon;&tau;&alpha;ί&omicron;&sigmaf;';
$lang['next'] = '&epsilon;&pi;ό&mu;&epsilon;&nu;&omicron;&sigmaf;';
$lang['previous'] = '&pi;&rho;&omicron;&eta;&gamma;&omicron;ύ&mu;&epsilon;&nu;&omicron;&sigmaf;';
