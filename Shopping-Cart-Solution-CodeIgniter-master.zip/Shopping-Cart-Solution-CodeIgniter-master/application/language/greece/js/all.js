var lang = { 
added_to_cart:"&Pi;&rho;&omicron;&sigma;&theta;ή&kappa;&eta; &sigma;&tau;&omicron; &Kappa;&alpha;&lambda;ά&theta;&iota;",
error_to_cart:"&Pi;&rho;ό&beta;&lambda;&eta;&mu;&alpha; &mu;&epsilon; &tau;&omicron; &kappa;&alpha;&lambda;ά&theta;&iota;! &Delta;&omicron;&kappa;&iota;&mu;ά&sigma;&tau;&epsilon; &xi;&alpha;&nu;ά!",
no_products:"&Delta;&epsilon;&nu; &upsilon;&pi;ά&rho;&chi;&omicron;&upsilon;&nu; &sigma;&tau;&omicron;&iota;&chi;&epsilon;ί&alpha;",
confirm_clear_cart:"&Epsilon;ί&sigma;&tau;&epsilon; &beta;έ&beta;&alpha;&iota;&omicron;&iota; ό&tau;&iota; &theta;έ&lambda;&epsilon;&tau;&epsilon; &nu;&alpha; &alpha;&delta;&epsilon;&iota;ά&sigma;&epsilon;&tau;&epsilon; &tau;&omicron; &kappa;&alpha;&lambda;ά&theta;&iota;;",
cleared_cart:"&Tau;&omicron; &kappa;&alpha;&lambda;ά&theta;&iota; &sigma;&alpha;&sigmaf; &epsilon;ί&nu;&alpha;&iota; ά&delta;&epsilon;&iota;&omicron;",
are_you_sure:"&Epsilon;ί&sigma;&alpha;&iota; &sigma;ί&gamma;&omicron;&upsilon;&rho;&omicron;&sigmaf;;",
yes:" ό&tau;&iota;",
no:"&delta;&epsilon;&nu;",
clear_all:"&sigma;&alpha;&phi;ή&sigmaf;",
checkout:"&pi;&lambda;&eta;&rho;&omega;&mu;ή",
remove_from_cart:"&Delta;&iota;&alpha;&gamma;&rho;ά&phi;&omicron;&nu;&tau;&alpha;&iota; &alpha;&pi;ό &tau;&omicron; &kappa;&alpha;&lambda;ά&theta;&iota;",
enter_valid_email:"&Pi;&alpha;&rho;&alpha;&kappa;&alpha;&lambda;ώ &epsilon;&iota;&sigma;ά&gamma;&epsilon;&tau;&epsilon; &mu;&iota;&alpha; έ&gamma;&kappa;&upsilon;&rho;&eta; &delta;&iota;&epsilon;ύ&theta;&upsilon;&nu;&sigma;&eta; &eta;&lambda;&epsilon;&kappa;&tau;&rho;&omicron;&nu;&iota;&kappa;&omicron;ύ &tau;&alpha;&chi;&upsilon;&delta;&rho;&omicron;&mu;&epsilon;ί&omicron;&upsilon;",
discountCodeInvalid: "Ο κωδικός δεν είναι έγκυρος"
};